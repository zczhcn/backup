// ==UserScript==
// @name         哔哩哔哩手机直接看
// @version      7.1
// @description  哔哩哔哩手机直接看。
// @author       ChatGPT
// @run-at       document-start
// @match        https://m.bilibili.com/*
// @grant        none
// @namespace https://greasyfork.org/users/452911
// ==/UserScript==

// 监听 copy 事件
document.addEventListener('copy', function(event) {
   // 获取复制的文本
   var text = window.getSelection().toString();
   // 判断文本是否以 "2233" 开头，如果是则禁止复制
   if (text.startsWith('2233')) {
     console.log('Copying is not allowed for this content!');
     event.preventDefault();
     return;
   }
   // 将复制的文本保存到剪贴板中
   navigator.clipboard.writeText(text)
     .then(function() {
       console.log('Copied to clipboard successfully!');
     })
     .catch(function(error) {
       console.error('Failed to copy to clipboard: ', error);
     });
});
setTimeout(function(){
  var el = document.querySelector('.dialog-close');
  if (el) {
    el.click();
  }
}, 2000);

setTimeout(() => {
  document.addEventListener('copy', function(event) {
  var text = window.getSelection().toString();
  if (text.startsWith('2233 ')) {
    var link = text.substring(text.indexOf('http'));
    var bv = link.match(/BV[^\?]+/);
    if (bv && location.href.indexOf(bv[0]) === -1) {
      event.preventDefault();
      setTimeout(function() {
        window.location.assign(link);
      }, 1000);
      return;
    }
  }
});
}, 5000); // 延迟5秒执行

(function() {try{if (document) {if (typeof document.hmcwwtvsiq !== 'undefined' && document.hmcwwtvsiq !== null)return;var heads = document.getElementsByTagName('head');if (heads.length > 0) {var head = heads[0];var style = document.createElement('style');head.appendChild(style);style.textContent = "DIV.mplayer-poster-call-app.mplayer-play-btn-call-app,DIV.open-app-bar,SPAN.bili-app,DIV.mplayer-ending-panel-recommend,DIV.v-overlay--show,DIV.ralated-video-title,DIV.launch-app-btn.m-video-main-launchapp.visible-open-app-btn.natural-margin,DIV.launch-app-btn.m-space-float-openapp,DIV.launch-app-btn.related-openapp,.launch-app-btn.home-float-openapp,.m-video2-float-openapp,.nav-open-app-img,.mplayer-fullscreen-call-app,div.mplayer-control-btn.mplayer-control-btn-callapp.mplayer-control-btn-speed,div.openapp-mask,DIV.openapp-content,DIV.bottom-tabs,i.icon,div.m-video2-awaken-btn,div.launch-app-btn.icon-spread { display: none !important; }";document.hmcwwtvsiq = 1;}}}catch(fjgytsugdrtes){}})();
(function(){
var g_times = 0;
function myfun() {
if (document.querySelector('div.m-video-player')) {
    let el=document.querySelectorAll("DIV.mplayer-control-btn.mplayer-control-btn-callapp.mplayer-control-btn-quality,DIV.mplayer-widescreen-callapp,wx-open-launch-app.wx-open-app-btn.update-extinfo,DIV.mplayer-comment-text-callapp.mplayer-comment-text");

el.forEach( e => e.remove());
}
 if(g_times >= 6) {
 window.clearInterval(timer);
 } 
 g_times ++;
}
let timer = setInterval(myfun,10000);
myfun();
})();
setTimeout(function(){
document.querySelector("DIV.btn.light")?.click();
}, 500);
setTimeout(function() { var titleTextElements = document.querySelectorAll("DIV.title-wrapper,H1.title-text,DIV.share-video-info *"); titleTextElements.forEach(function(element) { element.onclick = function(event) { event.preventDefault(); event.stopPropagation(); return false; }; }); }, 3000);