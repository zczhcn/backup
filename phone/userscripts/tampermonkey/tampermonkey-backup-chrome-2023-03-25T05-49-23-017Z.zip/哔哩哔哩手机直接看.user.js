// ==UserScript==
// @name         哔哩哔哩手机直接看
// @version      3.3
// @description  哔哩哔哩手机直接看。
// @author       ChatGPT拼凑
// @run-at       document-start
// @match        https://m.bilibili.com/*
// @grant        none
// @namespace https://greasyfork.org/users/452911
// ==/UserScript==
document.addEventListener('copy', function(e) {
    var text = window.getSelection().toString();
    if (text.startsWith('2233 ')) {
        var link = text.substring(text.indexOf('http'));
        setTimeout(function() {
            window.location.assign(link);
        }, 2000);
    }
});
(function() {try{if (document) {if (typeof document.hmcwwtvsiq !== 'undefined' && document.hmcwwtvsiq !== null)return;var heads = document.getElementsByTagName('head');if (heads.length > 0) {var head = heads[0];var style = document.createElement('style');head.appendChild(style);style.textContent = "DIV.open-app-bar,SPAN.bili-app,DIV.mplayer-ending-panel-recommend,DIV.v-overlay--show,DIV.ralated-video-title,DIV.launch-app-btn.m-video-main-launchapp.visible-open-app-btn.natural-margin,DIV.launch-app-btn.m-space-float-openapp,DIV.launch-app-btn.related-openapp,.launch-app-btn.home-float-openapp,.m-video2-float-openapp,.nav-open-app-img,.mplayer-fullscreen-call-app,div.mplayer-control-btn.mplayer-control-btn-callapp.mplayer-control-btn-speed,div.openapp-mask,DIV.openapp-content,DIV.bottom-tabs,i.icon,div.m-video2-awaken-btn,div.launch-app-btn.icon-spread { display: none !important; }";document.hmcwwtvsiq = 1;}}}catch(fjgytsugdrtes){}})();
(function(){
var g_times = 0;
function myfun() {
if (document.querySelector('div.m-video-player')) {
    let el=document.querySelectorAll("DIV.mplayer-control-btn.mplayer-control-btn-callapp.mplayer-control-btn-quality,DIV.mplayer-widescreen-callapp,wx-open-launch-app.wx-open-app-btn.update-extinfo,DIV.mplayer-comment-text-callapp.mplayer-comment-text");

el.forEach( e => e.remove());
}
 if(g_times >= 200) {
 window.clearInterval(timer);
 } 
 g_times ++;
}
let timer = setInterval(myfun,10000);
myfun();
})();;
(function(){
var g_times = 0;
function myfun() {
//自动点击
if (window.location.href.includes('m.bilibili.com/video/')) {
    document.querySelector("SPAN.open-app-dialog-btn.cancel")?.click();
document.querySelector("DIV.btn.light")?.click();
document.querySelector("DIV.to-see")?.click();
}
document.querySelector("DIV.to-see")?.click();
 if(g_times >= 5) {
 window.clearInterval(timer);
 } 
 g_times ++;
}
let timer = setInterval(myfun,200);
myfun();
})();