//==UserScript==

// @name 网页链接添加下划线

// @namespace Violentmonkey Scripts

// @include *

// @version 0.1

// @author 那年那兔那些事

// @description 2021/11/14

// ==/UserScript==

setInterval(function(){

var a=document.getElementsByTagName("a");

for(let i=0;i<a.length;i++){

if(a[i].style.textDecoration!=="underline"){

a[i].style.textDecoration="underline";

}

}

},500);// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://m.inftab.com/#/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=inftab.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();