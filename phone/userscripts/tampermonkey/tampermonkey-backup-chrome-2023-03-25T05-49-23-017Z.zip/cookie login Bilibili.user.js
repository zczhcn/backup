// ==UserScript==
// @name cookie login Bilibili
// @namespace login
// @version 1.0
// @description use the cookie login Bilibili
// @author sunshy
// @match *://*.bilibili.com/*
// ==/UserScript==
function isPrivateMode() {
  return new Promise(function detect(resolve) {
    var yes = function() { resolve(true); }; // is in private mode
    var not = function() { resolve(false); }; // not in private mode

    function detectFirefox() {
      var isMozillaFirefox = 'MozAppearance' in document.documentElement.style;
      if (isMozillaFirefox) {
        if (indexedDB == null) yes();
        else {
          var db = indexedDB.open('inPrivate');
          db.onsuccess = not;
          db.onerror = yes;
        }
      }
      return isMozillaFirefox;
    }

    if (detectFirefox()) return;
    return not();
  });
}

var currentUrl = window.location.hostname.split('.').reverse();
var domain = currentUrl[1] + '.' + currentUrl[0];
switch (domain) {
  case 'bilibili.com':
    isPrivateMode().then(function(result) {
      if (result) {
        document.cookie = 'SESSDATA=cae257e6%2C1694955255%2Cfcbd1*31; Domain=.bilibili.com;';
      } else {
        document.cookie = 'SESSDATA=3dcc0e5f%2C1694954455%2C358ca%2A32; Domain=.bilibili.com;';
      }
    });
    break;
  default:
    break;
}