// ==UserScript==
// @name         Toolbox
// @namespace    https://greasyfork.org/zh-CN/users/908915-alger-lee
// @version      1.8.7.1
// @icon         https://www.downloadclipart.net/large/toolbox-png-picture.png
// @description  个人工具箱, 解除知乎豆瓣等流氓弹窗, 广告屏蔽, 「打开 app」 类诱导链接屏蔽,一些其他优化, 详见附加信息
// @author       Alger_Lee
// @license      MIT License
// @match        *://*.douban.com/*
// @match        *://*.zhangxinxu.com/*
// @match        *://developer.mozilla.org/*
// @match        *://*.yuedu.163.com/book_reader/*
// @match        *://*.nyaa.si/*
// @match        *://*.stackexchange.com/*
// @match        *://*.wangwenba.cn/*
// @match        *://ireader.com.cn/*
// @match        *://*.toutiao.com/*
// @match        *://*.51shucheng.net/*
// @match        *://xw.qq.com/*
// @match        *://*.ishuquge.com/*
// @match        *://www.liuweiguo.com/*
// @match        *://*.ptt.cc/bbs/*
// @match        https://searx.space/
// @match        https://ping.chinaz.com/*
// @match        https://*.juejin.cn/*
// @match        https://*.guancha.cn/*
// @match        https://*.oschina.net/*
// @match        https://*.jianshu.com/*
// @match        https://*.freecodecamp.org/*
// @match        https://*.lianjia.com/*
// @match        https://*.zhihu.com/*
// @match        https://metager.org/*
// @match        https://*.hetushu.com/book/*/*.html
// @match        https://*.ixigua.com/*
// @match        http://*.tinycorelinux.net/*
// @match        https://*.gushiwen.cn/guwen/*.aspx
// @grant        GM_addStyle
// @require      https://greasyfork.org/scripts/444823-floodlist/code/FloodList.js

// ==/UserScript==
const site = location.href;
// ========================= gushiwen =========================
if (site.includes("gushiwen")) {
  GM_addStyle(`
       .main3,.left{
           width: auto!important;
           max-width: 1000px;
       }
       .contson{
          font-family: serif;
          font-size: 18px;
          line-height: 2em;
       }
  `);
}
// ========================= tinycore =========================
if (site.includes("tinycore")) {
  GM_addStyle(`
     p{
       font-size: 16px!important;
       font-family: monospace,Menlo,serif!important;
     }
  `);
}
// ========================= metager =========================
if (site.includes("metager")) {
  GM_addStyle(`
      .result{
        border-radius: 4px;
        box-shadow:1px 1px 2px 1px rgb(191 209 225)!important;
        margin-bottom: 14px;
      }
      .result-title a{color: #000bbb!important;}
      input,select{
        border: none!important;
        outline: none!important;
      }
      #quicktips{
        margin-right: 20px;
        width: auto!important;
      }
      #quicktips>.quicktip[type='wikipedia']{
        border-radius: 4px!important;
        margin: 8px!important;
      }
      .quicktip-detail:last-child{border:none!important;}
      #research-bar-container{
        border: none!important;
      }
      #research-bar{
        border: none!important;
        box-shadow: 0 0 0px 1px;
      }
  `);
}
// ========================= 和图书 =========================
if (site.includes("hetushu")) {
  GM_addStyle(`
      body{
        font-family: serif!important;
      }
      body[data-mode=night], #cbox #content {
        background-color: #212429!important;
        color: #a2a2a3!important;
      }
  `);
}
// ========================= 知乎登录弹窗 =========================
if (site.includes("zhihu")) {
  GM_addStyle(`
      .Modal-wrapper,
      .OpenInAppButton,
      .MobileAppHeader-actions,
      .MobileAppHeader-downloadLink,
      .AppBanner,
      .AppBanner-content,
      .Banner-link,
      .MRelateFeedAd,
      .AdBelowMoreAnswers,
      #div-gpt-ad-bannerAd,
      .MBannerAd,
      .WeiboAd-wrap,
      .MHotFeedAd,
      .GoodsRecommendCard,
      .RichText-ADLinkCardContainer,
      .KfeCollection-PaidAnswerFooter,
      .ExploreHomePage-specialsLogin,
      #js-openInApp{
        display: none!important;
      }
      html{
        overflow: auto!important;
      }
      .ExploreHomePage-square>div:nth-of-type(3){
        margin-top: 0!important;
      }
  `);
}
// =========================豆瓣登录弹窗=========================
if (site.includes("douban")) {
  if (location.host === "m.douban.com") {
    GM_addStyle(`
      #TalionNav .TalionNav-static,
      .download-app,
      div.center,
      .subject-banner,
      .app-link,
      .write-comment,
      .write-review,
      .score-write,
      .vendor-go-app,
      section h2 > a,
      section h1 ~ a,
      .section-header_link,
      .subject-annotations .show-all,
      div[style="position: relative;margin: 0 -18px"]{
        display: none!important;
      }
      .page{
        margin-top: 50px!important;
      }
      .card .subject-intro{
        margin-top: 20px!important;
      }
      .subject-reviews{
        margin-bottom: 0!important;
      }
  `);
    if (site.includes("home_guide")) {
      GM_addStyle(`
        #app{
          display: none;
        }
      `);
    }
    if (site.includes("movie")) {
      GM_addStyle(`
        #app section:nth-of-type(2),#app section:nth-of-type(3){
          display: none;
        }
      `);
    }
  } else {
    GM_addStyle(`
      html body, html td, html th, html .pl, html input,
      .rich-content p, .note p, .rich-content blockquote,
      .note blockquote{
        font-size:15px!important;
      }
      .ui-overlay-mask,.aside .ticket{display:none!important}
      #comments-section .comment-item,
      .blockquote-list figure,
      .comments-app-wrapper,
      #topic-items .item-status .status-preview, #topic-items .item-status .status-full{
        font-size:14px!important;
      }
    `);
  }
}
// =========================链家网=========================
if (/lianjia/.test(site)) {
  GM_addStyle(`
    .mask-login{
      display:none!important;
    }
    body{
      overflow: auto!important;
    }
  `);
}
// =========================searx.space=========================
if (site.includes("searx.space")) {
  GM_addStyle(`
    .table-responsive{
      overflow-x:inherit;
    }
    .table-bordered {
      table-layout: fixed;
    }
    .table-bordered>thead>tr:first-child>th{
      background: #fff;
      position: sticky;
      top: 0;
    }
    .table-bordered>tbody>tr>td:first-child{
      background: #fff;
      position: sticky;
      left: 0;
    }
    th.column-certificate,th.column-network{
      width:120px;
    }
    th.column-url{
      width:250px;
    }
    th.column-version{
      width:100px;
    }
    th.column-ipv6,td.column-ipv6{
      display: none;
    }
  `);
}

//======== 西瓜视频搜索弹出验证 ================

if (/ixigua/.test(site)) {
  GM_addStyle(`
    #captcha_container{
      display: none!important;
    }
  `);
}
(function () {
  ("use strict");
  function wordsStatistics(target) {
    // ele 为单个元素或者 NodeList
    const reg = /[\u4e00-\u9fa5]|\d+|\w+/g;
    let count = 0;
    if (target.length) {
      target.forEach((p) => {
        const text = p.innerText.trim();
        const matchArr = text.match(reg);
        if (text && matchArr) {
          count += matchArr.length;
        }
      });
    } else {
      count = target.innerText.match(reg).length;
    }
    let readTime = count / 600;
    readTime =
      readTime >= 1
        ? Math.ceil(readTime) + " 分钟"
        : Math.ceil(readTime * 60) + " 秒";
    return { count, readTime };
  }
  // =========================观察者网文章字数统计=========================
  if (/guancha.cn/.test(site)) {
    const pList = document.querySelectorAll(".article-txt-content p");
    const satistics = wordsStatistics(pList);
    const timeSpan = document.querySelector(".time1");
    timeSpan.innerText =
      timeSpan.innerText +
      ` | 本文共 ${satistics.count}字, 阅读大约需要 ${satistics.readTime}`;
  }

  // =========================zhihu不登录浏览=========================
  if (/zhihu.*?signin/.test(site)) {
    const btn = document.querySelector(".css-vurnku button");
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopImmediatePropagation();
      location.assign("https://www.zhihu.com/explore");
    });
    btn.innerHTML = `<svg class="icon" style="width: 20px;height: 20px;vertical-align: middle;fill: currentColor;overflow: hidden;margin-right: 6px" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="713"><path d="M805.973333 419.2a128 128 0 1 0-71.466666-166.186667 128 128 0 0 0 71.466666 166.186667z m-31.786666-150.4a85.333333 85.333333 0 1 1 0 65.28 85.333333 85.333333 0 0 1 0-65.28zM951.68 558.293333a192 192 0 0 1-252.16-100.693333A192 192 0 0 0 448 356.906667l-19.626667 8.533333a21.333333 21.333333 0 1 0 16 39.893333l19.626667-8.533333a149.333333 149.333333 0 0 1 196.053333 78.293333A234.666667 234.666667 0 0 0 968.32 597.333333a21.333333 21.333333 0 0 0-16.64-39.04zM597.333333 539.306667a65.92 65.92 0 0 0-93.013333-14.293334L52.48 814.08a21.333333 21.333333 0 0 0 23.04 36.053333l452.906667-290.133333a24.533333 24.533333 0 0 1 18.773333-5.333333 21.333333 21.333333 0 0 1 14.933333 9.173333l71.04 99.626667a27.306667 27.306667 0 0 1-21.333333 42.666666L362.666667 717.013333a21.333333 21.333333 0 0 0-21.333334 21.333334 21.333333 21.333333 0 0 0 21.333334 21.333333l250.666666-10.88a69.973333 69.973333 0 0 0 54.613334-108.8zM64 715.52a21.333333 21.333333 0 0 0 11.306667-3.413333l152.746666-96.853334a21.333333 21.333333 0 1 0-22.826666-36.053333L52.48 676.266667A21.333333 21.333333 0 0 0 64 715.52zM103.253333 587.52a21.333333 21.333333 0 0 0 11.093334-3.2l88.746666-54.186667a21.333333 21.333333 0 1 0-21.333333-36.48l-89.6 54.4a21.333333 21.333333 0 0 0 11.093333 39.466667z" style="fill: #0066ff; stroke: #0066ff; stroke-width: 45;" p-id="714"></path></svg>不登录浏览`;
  }
  // ========================= freeCodeCamp 文章字数统计=========================
  if (/freecodecamp/.test(site)) {
    const post = document.querySelector(".post-content");
    const satistics = wordsStatistics(post);
    const timeSpan = document.querySelector("#banner");
    timeSpan.innerText = `本文共 ${satistics.count}字, 阅读大约需要 ${satistics.readTime}`;
  }
  // ========================= 西瓜视频 =========================
  if (/ixigua/.test(site)) {
    setInterval(() => {
      let close = document.querySelector("#verify-bar-close");
      if (close) {
        close.click();
      }
    }, 100);
    return;
  }
  // =========================检测有效 ip =========================
  if (/chinaz/.test(site)) {
    function getIp() {
      let hosts = [];
      document.querySelectorAll(".listw").forEach((item) => {
        let resTime = item.querySelector("[name=responsetime]").innerText;
        let ip = item.querySelector("[name=ip]").innerText;
        if (/\d+/.test(resTime)) {
          hosts.push({
            resTime: resTime.match(/\d+/)[0],
            ip: ip + " " + location.pathname.replace(/\//, ""),
          });
        }
      });
      let res = "";
      let ipSet = new Set();
      hosts
        .sort((a, b) => a.resTime - b.resTime)
        .forEach((item) => ipSet.add(item.ip));
      for (const ip of ipSet) {
        res += ip + "\n";
      }
      console.log({ result: res });
      console.log("检测完成, 请拷贝 hosts 字符串的值到 /etc/hosts");
    }
    const reqNo = document
      .querySelector("li.item:nth-child(1)")
      .innerText.match(/\d+/)[0];
    new MutationObserver((mutations) => {
      console.log("正在检测,请稍候...");
      for (let mutation of mutations) {
        mutation.addedNodes[0] && mutation.addedNodes[0].nodeValue === reqNo
          ? getIp()
          : null;
      }
    }).observe(document.querySelector("#gjd"), { childList: true });
  }
  // ========================= 今日头条 =========================
  if (/toutiao/.test(site)) {
    function init(ele) {
      if (/feed-card-wrapper/.test(ele.getAttribute("class"))) {
        if (floodList.test(ele.innerText)) {
          // console.log(ele.innerText);
          ele.style.display = "none";
        }
      } else {
        ele.querySelectorAll(".feed-card-wrapper").forEach((item) => {
          if (floodList.test(item.innerText)) {
            // console.log(item.innerText);
            item.style.display = "none";
          }
        });
      }
    }
    init(document.body);
    new MutationObserver((mutations) => {
      for (let mutation of mutations) {
        const addedNodes = mutation.addedNodes;
        addedNodes.forEach((item) => {
          item.nodeType === 1 ? init(item) : null;
        });
      }
    }).observe(document.body, { childList: true, subtree: true });
  }
  // =========================自动切换MDN到中文环境=========================
  if (location.host === "developer.mozilla.org") {
    if (!localStorage.getItem("mdn_zh_404")) {
      localStorage.setItem("mdn_zh_404", JSON.stringify({}));
    }
    if (site.includes("en-US")) {
      const cnUrl = site.replace(/en-US/, "zh-CN");
      const isExist = !JSON.parse(localStorage.getItem("mdn_zh_404"))[cnUrl];
      if (isExist) {
        location.assign(cnUrl);
      }
    }

    if (site.includes("zh-CN")) {
      const enUrl = site.replace(/zh-CN/, "en-US");
      const _404 =
        document.querySelector(".sorry-message") ||
        /Page\s+not\s+found/i.test(document.querySelector("h1").innerText);
      if (_404) {
        const missedCnPages = JSON.parse(localStorage.getItem("mdn_zh_404"));
        missedCnPages[site] = true;
        localStorage.setItem("mdn_zh_404", JSON.stringify(missedCnPages));
        location.assign(enUrl);
      }
    }
    return;
  }
  // =========================自动跳转外链=========================
  function setDirectUrl() {
    document.querySelectorAll("a").forEach((a) => {
      const r = /(?<=go\?to=|gotolink\?url=|\?target=)http.*/i;
      if (r.test(a.href)) {
        a.href = decodeURIComponent(a.href.match(r)[0]);
      }
    });
  }
  setTimeout(setDirectUrl, 2000);
  // =========================樱花动漫优化=========================
  if (site.includes("wangwenba")) {
    document.body.style.background = "white";
    return;
  }

  // =========================滚动事件绑定 ===============================
  const EventUtil = {
    addHandler: function (element, type, handler) {
      if (element.addEventListener)
        element.addEventListener(type, handler, false);
      else if (element.attachEvent) element.attachEvent("on" + type, handler);
      else element["on" + type] = handler;
    },
    removeHandler: function (element, type, handler) {
      if (element.removeEventListener)
        element.removeEventListener(type, handler, false);
      else if (element.detachEvent) element.detachEvent("on" + type, handler);
      else element["on" + type] = handler;
    },
    /**
     * 监听触摸的方向
     * @param target            要绑定监听的目标元素
     * @param isPreventDefault  是否屏蔽掉触摸滑动的默认行为（例如页面的上下滚动，缩放等）
     * @param upCallback        向上滑动的监听回调（若不关心，可以不传，或传false）
     * @param rightCallback     向右滑动的监听回调（若不关心，可以不传，或传false）
     * @param downCallback      向下滑动的监听回调（若不关心，可以不传，或传false）
     * @param leftCallback      向左滑动的监听回调（若不关心，可以不传，或传false）
     */
    listenTouchDirection: function (
      target,
      isPreventDefault,
      upCallback,
      rightCallback,
      downCallback,
      leftCallback
    ) {
      this.addHandler(target, "touchstart", handleTouchEvent);
      this.addHandler(target, "touchend", handleTouchEvent);
      this.addHandler(target, "touchmove", handleTouchEvent);
      var startX;
      var startY;
      function handleTouchEvent(event) {
        switch (event.type) {
          case "touchstart":
            startX = event.touches[0].pageX;
            startY = event.touches[0].pageY;
            break;
          case "touchend":
            var spanX = event.changedTouches[0].pageX - startX;
            var spanY = event.changedTouches[0].pageY - startY;

            if (Math.abs(spanX) > Math.abs(spanY)) {
              //认定为水平方向滑动
              if (spanX > 30) {
                //向右
                if (rightCallback) rightCallback();
              } else if (spanX < -30) {
                //向左
                if (leftCallback) leftCallback();
              }
            } else {
              //认定为垂直方向滑动
              if (spanY > 30) {
                //向下
                if (downCallback) downCallback();
              } else if (spanY < -30) {
                //向上
                if (upCallback) upCallback();
              }
            }

            break;
          case "touchmove":
            //阻止默认行为
            if (isPreventDefault)
              //event.preventDefault();
              break;
        }
      }
    },
  };
  // =========================小说网站优化 公共方法=========================
  function filter(title, prePage, nextPage, content, flag) {
    // content: doc.querySelector('.content').innerHTML
    // flag 段落分割标记
    //翻页
    console.log(title);
    if (!title.includes("章")) {
      //如果不是章节（比如请假/节日问候等）自动跳到下一章
      nextPage.click();
      return;
    }
    document.onkeydown = function (e) {
      if (e.key === "ArrowLeft") {
        prePage.click();
      } else if (e.key === "ArrowRight") {
        nextPage.click();
      } else if (e.key === "R") {
        window.location.reload();
      }
      return;
    };
    //content优化
    let regDel =
      /.一幕.*出现|章节错误,点此报送|第.*?章|一秒记住|请耐心等待|记住网址|你就是我，我就是你，|域名|公众号|回复“速见韩立|https|等3D形象|群号|票票|本站|书友|新书|粉丝|更.*哦|推荐.*《|月票|手机阅读|&1t|首发网址|求收藏/g;
    let regUrl = /^\s*https:/g;
    let regReplace = /哥哥|妹妹|此女|此子|妾身|为夫|夫君|仙子|美眸/g;
    let regSpace =
      /电子书坊|90看|九桃|综艺文学|梦想中文|第一读书网|59书库|电子书/g;
    let paragraphs = content.split(flag);
    let newContents = paragraphs
      .filter((item) => !/^\s*\n\s*$|^\s*$/.test(item))
      .map((item) => {
        if (regDel.test(item) || regUrl.test(item)) {
          console.log("deleted: " + item);
          return "";
        }
        item = item.replace(regSpace, ($1) => {
          console.log("deleted: " + $1);
          return "";
        });

        if (regReplace.test(item)) {
          return `<p title='原文：${item.replace(
            /\s|<p>/g,
            ""
          )}' style='background-color:rgb(155,237,140);'>${item
            .replace(regReplace, ($) => {
              let tokenMap = {
                哥哥: "\u5927\u715e\u7b14",
                妹妹: "\u5c0f\u715e\u7b14",
                此女: "\u6b64\u8d31\u4eba",
                此子: "\u8fd9\u4e2a\u715e\u7b14",
                妾身: "\u672c\u8d31\u4eba",
                为夫: "\u672c\u6c99\u96d5",
                夫君: "\u715e\u7b14",
                仙子: "\u4ed9\u5c4e",
                美眸: "\u9b3c\u7738",
              };
              return tokenMap[$];
            })
            .replace(/<p>|<\/p>/g, "")}</p>`;
        }
        return flag === "</p>" ? item : `<p>${item}</p>`;
      });
    return newContents.join(flag);
  }

  // =========================ireader=========================
  if (site.includes("ireader")) {
    let iframe = document.getElementById("iframe_chapter");
    if (iframe) {
      let contentDom = iframe.contentDocument.querySelector(".h5_mainbody");
      let content = { str: contentDom.innerText };
      console.dir(content);
      return;
    }
  }

  // =========================shuquge=========================
  if (site.includes("shuquge")) {
    let prePage = document.querySelector(
      ".page_chapter ul>li:nth-of-type(1)>a"
    );
    let nextPage = document.querySelector(
      ".page_chapter ul>li:nth-of-type(3)>a"
    );
    let contentDOM =
      document.querySelector("#content") || document.querySelector("#nr1");
    let content = "";
    if (contentDOM) {
      //正文页面
      content = contentDOM.innerHTML;
    } else {
      return;
    }
    // 标题位置重置
    let re = /(?<=width=)\d+/;
    let cookie = document.cookie;
    if (re.test(cookie)) {
      let w = cookie.match(re)[0];
      document.querySelector("h1").style.width = w + "%";
    }
    // NightMode
    let currentHour = new Date().getHours();
    let nightBox = document.querySelector("#night");
    if (nightBox) {
      if (currentHour >= 23 || currentHour <= 6) {
        nightBox.checked ? null : nightBox.click();
      } else {
        nightBox.checked ? nightBox.click() : null;
        document.querySelector(
          "#page_set>select:nth-of-type(5)"
        ).options[6].selected = true;
      }
    }
    // 禁用水平滚动条
    let clientW = document.documentElement.clientWidth;
    document.documentElement.style.overflowX =
      clientW >= 450 ? "hidden" : "visible";
    let titleDom =
      document.querySelector(".content h1") ||
      document.querySelector("#_bqgmb_h1");
    titleDom.innerText = titleDom.innerText.replace(/（.*）/g, "");
    let title = titleDom.innerText; //章节标题
    contentDOM.innerHTML = filter(title, prePage, nextPage, content, "<br>");
    GM_addStyle(`p{text-indent: 2em;}`);
    document.querySelectorAll("p").forEach((item) => {
      item.innerHTML = item.innerHTML.replace(/&nbsp;/g, "");
    });
    // 屏蔽推荐
    document
      .querySelectorAll(".link")
      .forEach((item) => (item.style.display = "none"));
    EventUtil.listenTouchDirection(document, true, function () {
      let target = document.documentElement;
      if (target.scrollHeight - target.scrollTop === target.clientHeight) {
        document.querySelector("#pb_next").click();
      }
    });
    return;
  }

  // =========================无忧书城=========================
  if (site.includes("51shucheng")) {
    let prePage = document.getElementById("BookPrev");
    let nextPage = document.getElementById("BookNext");
    let contentDOM = document.querySelector("#neirong");
    let content = "";
    if (contentDOM) {
      //正文页面
      content = contentDOM.innerHTML;
    } else {
      return;
    }
    let titleDom = document.querySelector(".content h1");
    titleDom.innerText = titleDom.innerText.replace(/\(.*\)/g, "");
    let title = titleDom.innerText; //章节标题
    contentDOM.innerHTML = filter(title, prePage, nextPage, content, "</p>");
    // 设置背景色为豆沙绿rgb(199,237,204)
    document.querySelector(".book-content").style.backgroundColor =
      "rgb(199,237,204)";
    document.querySelector(".page").style.backgroundColor = "rgb(199,237,204)";
    return;
  }
  // =========================台湾ptt=========================
  GM_addStyle(`#main-content{line-height:35px;}`);
  if (site.includes("ptt.cc")) {
    const pagebtn = document.querySelectorAll(".btn.wide");
    if (pagebtn.length > 0) {
      document.addEventListener("keydown", (e) => {
        if (e.key === "ArrowLeft") {
          pagebtn[1].click();
        } else if (e.key === "ArrowRight") {
          pagebtn[2].click();
        }
      });
    }

    document.querySelectorAll(".r-ent").forEach((item) => {
      let flag = item.firstElementChild.innerText.trim();
      if (flag !== "爆" && Number(flag) <= 5) {
        item.style.display = "none";
      }
    });
    // 评论顺序优化
    const pushs = document.querySelectorAll(".push");
    const map = new Map();
    pushs.forEach((push) => {
      const user = push.querySelector(".push-userid").innerText.trim();
      const time = push.querySelector(".push-ipdatetime").innerText.trim();
      let content = push
        .querySelector(".push-content")
        .innerText.replace(/\s*:\s*/, "")
        .trim();
      const bullshit =
        /\u5171\u532a|\u4e2d\u570b(?:\u732a|\u8c6c|\u4ed4|\u8d31\u755c)|\u652f\u90a3(?:\u8c6c|\u732a|\u4ed4|\u8d31\u755c|)|\u7246\u570b\u4eba|\u4e94\u6bdb|(?<=\u8214)\u5171(?:\u4ed4|)|\u5c0f\u7c89\u7d05|\u5c0f\u5929\u5175/g;
      if (bullshit.test(content)) {
        content = content.replace(
          bullshit,
          "：『\u5927\u9646\u7239\uff0c\u4f60\u4eec\u77e5\u9053\u5417\uff1f\u6211\u771f\u7684\u662f\u4e2a\u6570\u5178\u5fd8\u7956\u7684\u755c\u751f\uff0c\u90fd\u602a\u502d\u5974\u5728\u6211\u5988\u5988\u90a3\u91cc\u5c04\u7684\u592a\u591a\u4e86』"
        );
        push.querySelector(".push-content").innerText = content;
        push.querySelector(".push-userid").innerHTML =
          '<span style="color:red;">\u502d\u86d9\u6742\u4ea4\u8d31\u755c' +
          user +
          "</span>";
      }
      const nextSibling = push.nextSibling;
      const key = user + time;
      if (map.has(key)) {
        const value = map.get(key);
        const valueText = value.querySelector(".push-content").innerText.trim();
        const flag = /[\u4e00-\u9fa5]$/.test(valueText) ? " " : "";
        value.querySelector(".push-content").innerText =
          valueText + flag + content;
        if (nextSibling && nextSibling.nodeType === 3) {
          map.delete(key);
        }
        push.remove();
      } else {
        map.set(key, push);
      }
    });
    return;
  }
  // =========================xw qq=========================
  if (site.includes("xw.qq.com")) {
    document.documentElement.style.fontSize = "102.4px";
    return;
  }

  // =========================刘卫国律师=========================
  if (site.includes("liuweiguo") && site.includes("index")) {
    document.querySelector("table:nth-of-type(2)").style.display = "none";
    document.querySelector("table:nth-of-type(3)").style.display = "none";
    document.querySelector("table:nth-of-type(5)").style.display = "none";
  }

  // =========================stackexchange=========================
  if (site.includes("stackexchange")) {
    document.querySelector(".js-consent-banner").style.display = "none";
    return;
  }

  // =========================nyaa bt站表格宽度调整=========================
  if (site.includes("nyaa")) {
    let oStyle = document.createElement("style");
    oStyle.innerText = `.torrent-list > tbody > tr > td {vertical-align: middle;white-space: normal;max-width: 603px;}`;
    document.documentElement.appendChild(oStyle);
    return;
  }

  // =========================张鑫旭博客广告=========================
  if (site.includes("zhangxinxu")) {
    let children = document.body.children;
    for (let key in children) {
      if (
        children[key].tagName.toLowerCase() !== "div" &&
        children[key].tagName.toLowerCase() !== "script"
      ) {
        console.log(children[key]);
        document.body.removeChild(children[key]);
      }
    }
    return;
  }

  // =========================拉取网易云阅读内容=========================
  if (site.includes("yuedu.163")) {
    let deltaY = 0;
    window.onwheel = function (e) {
      deltaY = e.deltaY; //判断鼠标滚动方向：向下滚动(>0),向上滚动(<0)
    };
    const target = document.querySelector(".portrait-page-box");
    const config = { childList: true };

    let book = { all: "" };
    const observer = new MutationObserver(function (mutations, observer) {
      for (let mutation of mutations) {
        let addedNodes = mutation.addedNodes;
        if (
          mutation.type === "childList" &&
          deltaY >= 0 &&
          addedNodes.length > 0
        ) {
          let reg = /(\d+\.\d+%)/g;
          let content = addedNodes[addedNodes.length - 1].innerText.replace(
            reg,
            "全书阅读进度：$1\n"
          );
          let indexOfFirstEnter = content !== "" ? content.indexOf("\n") : null;
          let title = content.substring(0, indexOfFirstEnter); //截取首行---章节题目
          if (!book[title]) {
            book[title] = {};
            book[title] = content;
            book.all += content;
          }
          console.log(book);
        }
      }
    });

    observer.observe(target, config);
    return;
  }
})();
