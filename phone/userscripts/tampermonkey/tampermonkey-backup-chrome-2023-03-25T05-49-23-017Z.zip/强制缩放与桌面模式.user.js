// ==UserScript==
// @name        强制缩放与桌面模式
// @author      酷安@耗子Sky
// @description 浏览器ua为手机ua时启用强制缩放，浏览器ua非手机ua时启用桌面模式
// @match       *://*/*
// @grant       none
// @version     5.0
// @run-at      document-end
// @author      -
// @namespace https://greasyfork.org/users/452911
// ==/UserScript==

(function() {
  // 强制缩放比例
  const FORCE_SCALE = 1.0;
  // 默认视口宽度
  const DEFAULT_WIDTH = 1080;
  
  // 获取meta标签
  const metaTag = document.querySelector('meta[name=viewport]');
  // 获取浏览器UA字符
  const userAgent = navigator.userAgent;
  
  // 修改缩放比例
  function changeScale(scale) {
    metaTag.setAttribute(
      'content',
      `width=device-width,initial-scale=${scale},maximum-scale=10.0,user-scalable=1`);
  };
  
  // 自动根据屏幕尺寸调整缩放比例
  function autoChangeScale() {
    // 如果不是移动浏览器，则将视口宽度设为默认值
    if (userAgent.indexOf('Mobile') < 0) {
      metaTag.setAttribute('content', `width=${DEFAULT_WIDTH}`);
    }
    // 如果是移动浏览器且视口宽度小于默认值，则强制缩放
    else if (window.innerWidth < DEFAULT_WIDTH) {
      changeScale(FORCE_SCALE);
    }
  }
  
  // 初次加载页面时自动调整缩放比例
  autoChangeScale();
})();
if (navigator.userAgent.includes('SearchCraft baiduboxapp')) {
  !(function() {
    document.querySelector('meta[name=viewport]').setAttribute('content','width=device-width,initial-scale=1.0,maximum-scale=10.0,user-scalable=1');
})();
}